# -*- coding:utf-8 -*-


import logging
import os

DEFAULT_DATA_PATH = os.path.abspath(os.path.join(
    os.path.dirname(__file__), '..', 'SEC-Edgar-Data'))
