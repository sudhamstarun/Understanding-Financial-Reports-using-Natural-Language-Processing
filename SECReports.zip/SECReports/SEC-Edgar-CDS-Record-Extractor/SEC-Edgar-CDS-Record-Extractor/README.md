# SEC-Edgar-CDS-Record-Extractor

Dr. LUO, Ruibang  
rbluo@connect.hku.hk  

本程序致我尊敬的夫人王君瑜博士  
本程序对从SEC Edgar下载的N-Q, N-CSR和N-CSRS表格进行处理，抓取Credit Default Swap相关信息条目，并输出成格式化表格，其中包括Reference Entity, Holding Position, Notional Amount, Date以及Counterparty。  

以处理PIMCO FUNDS 17年二季度N-Q为例：  
```
perl ./extract.pl 0001193125-17-056504.txt.gz
```

输出结果共4103行  
输出前十行示范：  
```
META    KEYWORDS        1426
ITEM    0001193125      17      056504  0000810893      PIMCO FUNDS     02/24/2017      .       12/31/2016      MCDX-27 5-YEAR   INDEX  BUY     USD     400000  CBK
ITEM    0001193125      17      056504  0000810893      PIMCO FUNDS     02/24/2017      .       12/31/2016      DEUTSCHE BANK AG        SELL    EUR     100000  BOA
ITEM    0001193125      17      056504  0000810893      PIMCO FUNDS     02/24/2017      .       12/31/2016      DEUTSCHE BANK AG        SELL    EUR     100000  BPS
ITEM    0001193125      17      056504  0000810893      PIMCO FUNDS     02/24/2017      .       12/31/2016      DEUTSCHE BANK AG        SELL    EUR     100000  BRC
ITEM    0001193125      17      056504  0000810893      PIMCO FUNDS     02/24/2017      .       12/31/2016      DEUTSCHE BANK AG        SELL    EUR     100000  JPM
SKIP-NOCOUNTERPARTY     0001193125      17      056504  0000810893      PIMCO FUNDS     02/24/2017      .       12/31/2016      .       SELL    USD     .       .
ITEM    0001193125      17      056504  0000810893      PIMCO FUNDS     02/24/2017      .       12/31/2016      CANADIAN NATURAL RESOURCES LTD. SELL    USD     1900000 .
ITEM    0001193125      17      056504  0000810893      PIMCO FUNDS     02/24/2017      .       12/31/2016      3-MONTH USD-LIBOR       BUY     USD     76600000        .
ITEM    0001193125      17      056504  0000810893      PIMCO FUNDS     02/24/2017      .       12/31/2016      3-MONTH USD-LIBOR       BUY     USD     20460000
```
