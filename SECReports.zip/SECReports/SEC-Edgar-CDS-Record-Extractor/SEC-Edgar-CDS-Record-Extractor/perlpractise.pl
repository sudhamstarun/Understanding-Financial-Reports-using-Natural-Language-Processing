use strict;

my $str1 = "deeeefghi";
my $result = $str1 =~/de+f/;
print "Result : $result \n"; 