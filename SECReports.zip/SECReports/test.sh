#!/bin/bash


#below is working code
for dir in ~/Desktop/SECReports/SEC-Edgar-Data/*/
do
	for d in $dir/*/
	do
		if [ -d ~/Desktop/SECReports/N-CSR/$(basename $d) ]
		then
			(cd "$d" && cd ../../../N-CSR/ && cd ~/Desktop/SECReports/N-CSR/$(basename $d) && mkdir "$(basename $dir)" && cd "$d" && mv N-CSR  ~/Desktop/SECReports/N-CSR/$(basename $d)/$(basename $dir))

	else 
		(cd "$d" && cd ../../../N-CSR/ && mkdir "$(basename $d)" && cd ~/Desktop/SECReports/N-CSR/$(basename $d) && mkdir "$(basename $dir)" && cd "$d" && mv N-CSR  ~/Desktop/SECReports/N-CSR/$(basename $d)/$(basename $dir))
		
	fi

	if [ -d ~/Desktop/SECReports/N-CSRS/$(basename $d) ]
		then
			(cd "$d" && cd ../../../N-CSRS/ && cd ~/Desktop/SECReports/N-CSRS/$(basename $d) && mkdir "$(basename $dir)" && cd "$d" && mv N-CSRS  ~/Desktop/SECReports/N-CSRS/$(basename $d)/$(basename $dir))

	else 
		(cd "$d" && cd ../../../N-CSRS/ && mkdir "$(basename $d)" && cd ~/Desktop/SECReports/N-CSRS/$(basename $d) && mkdir "$(basename $dir)" && cd "$d" && mv N-CSRS  ~/Desktop/SECReports/N-CSRS/$(basename $d)/$(basename $dir))
		
	fi


	if [ -d ~/Desktop/SECReports/N-Q/$(basename $d) ]
		then
			(cd "$d" && cd ../../../N-Q/ && cd ~/Desktop/SECReports/N-Q/$(basename $d) && mkdir "$(basename $dir)" && cd "$d" && mv N-Q  ~/Desktop/SECReports/N-Q/$(basename $d)/$(basename $dir))

	else 
		(cd "$d" && cd ../../../N-Q/ && mkdir "$(basename $d)" && cd ~/Desktop/SECReports/N-Q/$(basename $d) && mkdir "$(basename $dir)" && cd "$d" && mv N-Q  ~/Desktop/SECReports/N-Q/$(basename $d)/$(basename $dir))
		
	fi

done
done


# (cd "$d" && cd ../../../N-CSRS/ && mkdir "$(basename $d)" && cd ~/Desktop/SECReports/N-CSRS/$(basename $d) && mkdir "$(basename $dir)" && cd "$d" && mv N-CSRS  ~/Desktop/SECReports/N-CSRS/$(basename $d)/$(basename $dir))
# (cd "$d" && cd ../../../N-Q/ && mkdir "$(basename $d)" && cd ~/Desktop/SECReports/N-Q/$(basename $d) && mkdir "$(basename $dir)" && cd "$d" && mv N-Q  ~/Desktop/SECReports/N-Q/$(basename $d)/$(basename $dir))

#above is working code


# (cd "$d" && cd ../../../N-CSR/ && mkdir "$(basename $d)" && cd "$d" && mv N-CSR  ~/Desktop/SECReports/N-CSR/$(basename $d) )
		# (cd "$d" && cd ../../../N-CSRS/ && mkdir "$(basename $d)" && cd "$d" && mv N-CSRS  ~/Desktop/SECReports/N-CSRS/$(basename $d) )
		# (cd "$d" && cd ../../../N-Q/ && mkdir "$(basename $d)" && cd "$d" && mv N-Q  ~/Desktop/SECReports/N-Q/$(basename $d) )